package com.wnc.example.grpc.note.service;

import com.wnc.example.grpc.note.data.NoteEntity;
import com.wnc.example.grpc.note.repository.NoteServiceDataRepository;
import io.grpc.Metadata;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import java.util.List;

public class NoteServiceGrpcImpl extends NoteServiceGrpc.NoteServiceImplBase {

    NoteServiceDataRepository noteServiceDataRepository = new NoteServiceDataRepository();

//    @Override
//    public void listNotes(Empty request, StreamObserver<NoteListResponse> responseObserver) {
//        List<NoteEntity> noteEntities = noteServiceDataRepository.findAllNotes();
//        for(NoteEntity note: noteEntities){
//            NoteListResponse.newBuilder().addNoteList(note.toProto()).build();
//        }
//        responseObserver.onNext(NoteListResponse.newBuilder().build());
//        responseObserver.onCompleted();
//    }

    @Override
    public void getNoteById(NoteRequestID noteRequestID, StreamObserver<NoteData> responseObserver) {
        NoteEntity noteEntity = noteServiceDataRepository.findNoteById(noteRequestID);
        if(noteEntity == null){
            Metadata metadata = new Metadata();
            responseObserver.onError(
                    Status.UNAVAILABLE.withDescription("Note not found !")
                            .asRuntimeException(metadata));
        }else {
            responseObserver.onNext(NoteData.newBuilder()
                    .setId(noteEntity.getId())
                    .setTitle(noteEntity.getTitle())
                    .setContent(noteEntity.getContent()).build());
            responseObserver.onCompleted();
        }
    }


    //    @Override
//    public void getNoteById(NoteRequestID noteRequestID, StreamObserver<NoteResponse> responseObserver) {
//        NoteEntity noteEntity = noteServiceDataRepository.findNoteById(noteRequestID);
//        if(noteEntity == null){
//            Metadata metadata = new Metadata();
//            responseObserver.onError(
//                    Status.UNAVAILABLE.withDescription("Note not found !")
//                            .asRuntimeException(metadata));
//        }else {
//            responseObserver.onNext(NoteResponse.newBuilder().setMessage("Response OK").build());
//            responseObserver.onCompleted();
//        }
//    }
}
