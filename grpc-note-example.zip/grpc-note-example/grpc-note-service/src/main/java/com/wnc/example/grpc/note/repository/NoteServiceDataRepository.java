package com.wnc.example.grpc.note.repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wnc.example.grpc.note.data.NoteEntity;
import com.wnc.example.grpc.note.service.NoteRequestID;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class NoteServiceDataRepository {
    Map<Long, NoteEntity> notesMap;

    public NoteServiceDataRepository(){
        notesMap = readNoteDataFromFileStore();
    }

    public NoteEntity createNote(NoteEntity noteEntity){
        notesMap.put(noteEntity.getId(), noteEntity);
        return noteEntity;
    }

    public NoteEntity updateNote(NoteEntity noteEntity){
        notesMap.put(noteEntity.getId(), noteEntity);
        return noteEntity;
    }

    public List<NoteEntity> findAllNotes(){
        return notesMap.values().stream().collect(Collectors.toList());
    }

    public NoteEntity findNoteById(NoteRequestID noteRequestID){
        return notesMap.values().stream()
                .filter(n -> n.getId().equals(noteRequestID.getNoteId()))
                .findFirst().get();
    }

    public void deleteNote(NoteRequestID noteRequest){
        notesMap.remove(noteRequest.getNoteId());
    }

    private Map<Long, NoteEntity> readNoteDataFromFileStore() {
        List<NoteEntity> noteEntities = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            InputStream jsonInput = NoteServiceDataRepository.class.getResourceAsStream("/note-data.json");
            noteEntities = mapper.readValue(jsonInput,
                    new TypeReference<List<NoteEntity>>() {
                    });
        } catch (Exception ex) {
            ex.printStackTrace();
            noteEntities = new ArrayList<NoteEntity>();
        }
        Map<Long, NoteEntity> deptsMap = noteEntities.stream().
                collect(Collectors.toMap(NoteEntity::getId, dept -> dept));
        return deptsMap;
    }
}
