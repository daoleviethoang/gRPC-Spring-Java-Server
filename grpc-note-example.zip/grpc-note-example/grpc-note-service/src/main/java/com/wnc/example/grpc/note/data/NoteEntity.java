package com.wnc.example.grpc.note.data;

import com.wnc.example.grpc.note.service.NoteData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteEntity {
    private Long id;
    private String title;
    private String content;

    public NoteData toProto(){
        return NoteData.newBuilder().setId(getId())
                .setTitle(getTitle())
                .setContent(getContent())
                .build();
    }

    public static NoteEntity fromProto(NoteData noteRequest){
        NoteEntity noteEntity = new NoteEntity();
        noteEntity.setTitle(noteRequest.getTitle());
        noteEntity.setContent(noteEntity.getContent());
        return noteEntity;
    }
}
